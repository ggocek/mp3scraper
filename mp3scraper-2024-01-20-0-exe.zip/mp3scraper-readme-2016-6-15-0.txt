﻿mp3scraper, copyright (c) 2016, Gary Gocek
All rights reserved.
Scrape web pages for MP3 links and generate RSS files.

If the programs fails completely, it's probably because the EXE can't find the
config file.

mp3scraper.exe and mp3scraper.exe.config should be in the same folder.

Users must edit the config file as needed. The program has no option to
restore the original settings, but you can get to this free and open-source
software via http://www.gocek.org/software/. The release files include a PDF
file with detailed instructions.

No "installation" is necessary - just run the EXE. No registry keys are used.

Acknowledgments:
freesound.org for a free chime sound for the test pages.

Thanks for investigating mp3scraper,
Gary Gocek, gary@gocek.org
